https://github.com/vanvught/h3dmx512-Firmware-Update-UI/releases
https://github.com/vanvught/Remote-Config-UI/releases (Legacy)
https://github.com/vanvught/wireshark
