*. Before upgrading the firmware it is advised to make a backup of the configuration:
  1. https://www.orangepi-dmx.org/orange-pi/remote-configuration-management-for-spi-flash
Or
  2. Use the latest sample UI -> https://github.com/vanvught/Remote-Config-UI/releases

*. After the upgrade, then restore the saved configuration. Then when RDM is used, please do
   check the RDM setting per port. 